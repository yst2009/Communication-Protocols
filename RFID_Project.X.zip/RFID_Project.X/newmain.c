/*
 * File:   newmain.c
 * Author: hp
 *
 * Created on October 4, 2026, 9:50 PM
 */


#include <xc.h>

void main(void) {
    return;
}
