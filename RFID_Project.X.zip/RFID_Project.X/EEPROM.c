#include "STD_TYPES.h"
#include "BIT_MATH.h"
#include "twi.h"
#include "EEPROM.h"

#define F_CPU 16000000UL
#include <util/delay.h>
#define EEPROM_ADDR 0x57 

/*
TWI_Start(void);
void    TWI_RepeatedStart(void);
void    TWI_Stop(void);
void    TWI_Write(u8 data);
u8 TWI_Read_With_ACK(void);
u8 TWI_Read_With_NACK(void);
u8 TWI_Get_Status(void);
*/
void EEPROM_Write(u16 address, u8 data)
{
    /* START */
    TWI_Start();

    /* SLA + W (????? ??????? + ?? ??????? 0) */
    TWI_Write((u8)((EEPROM_ADDR << 1) | 0));

    /* ????? ????? ??????? ??????? 16-bit ??? ?????? */
    TWI_Write((u8)(address >> 8));   // High Address Byte
    TWI_Write((u8)(address & 0xFF)); // Low Address Byte

    /* ????? ???? ???????? */
    TWI_Write(data);

    /* STOP */
    TWI_Stop();

    /* ???? ??? ???????? ??????? */
    _delay_ms(5);
}

/*
u8 EEPROM_Read(u16 address)
{
    u8 data;

    TWI_Start();

    TWI_Write((u8)((EEPROM_ADDR << 1) | 0));

    TWI_Write((u8)(address >> 8));   // High Address Byte
    TWI_Write((u8)(address & 0xFF)); // Low Address Byte

    TWI_RepeatedStart();

    TWI_Write((u8)((EEPROM_ADDR << 1) | 1));

    data = TWI_Read_With_NACK();

    TWI_Stop();

    return data;
}
*/
u8 EEPROM_Read(u16 address)
{
    u8 data;

    /* START */
    TWI_Start();

    TWI_Write((u8)((EEPROM_ADDR << 1) | 0));

    TWI_Write((u8)(address >> 8));   // High Address Byte
    TWI_Write((u8)(address & 0xFF)); // Low Address Byte

    TWI_RepeatedStart();

    TWI_Write((u8)((EEPROM_ADDR << 1) | 1));

    data = TWI_Read_With_NACK();

    /* STOP */
    TWI_Stop();

    return data;
}