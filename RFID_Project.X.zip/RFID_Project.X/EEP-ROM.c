/*
 * File:   EEP-ROM.c
 * Author: hp
 *
 * Created on October 4, 2026, 9:51 PM
 */


#include <avr/io.h>

int main(void) {
    /* Replace with your application code */
    while (1) {
    }
}
