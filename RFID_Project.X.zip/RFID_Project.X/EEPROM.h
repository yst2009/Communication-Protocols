
#ifndef EEPROM_H_
#define EEPROM_H_

#include <stdint.h>

/* EEPROM I2C Address */



void EEPROM_Write(u16 address, u8 data);

u8 EEPROM_Read(u16 address);

#endif
