#define F_CPU 16000000UL
#include <avr/io.h>
#include <util/delay.h>
#include "STD_TYPES.h"
#include "BIT_MATH.h"
#include "twi.h"       
#include "EEPROM.h"    
#include "UART.h"      

/* ================= 1. ??????? ?????????? ================= */
#define I2C_ACK             0
#define I2C_NACK            1

#define EEPROM_W_ADDR       0xA0    
#define EEPROM_R_ADDR       0xA1    

#define ID_START_ADDR       0x57   
#define TOTAL_IDS           3        
#define ATTEMPTS_ADDR       0x0020   
#define MAX_ATTEMPTS        3 
#define LED_GREEN           0        
#define LED_RED             1        

/* Write */
/*16-bit User Address
|
+---- High 8 bits
|       |
|       +-- A2
|       +-- A1
|       +-- A0
|
+---- Low 8 bits
|
+-- Memory Location
*/

void System_Init_IDs(void)
{
    EEPROM_Write(ID_START_ADDR + 0, 0x11);_delay_ms(10);
    EEPROM_Write(ID_START_ADDR + 1, 0x22);_delay_ms(10);
    EEPROM_Write(ID_START_ADDR + 2, 0x33);_delay_ms(10);
    EEPROM_Write(ATTEMPTS_ADDR, 0);_delay_ms(10);
}

u8 Search_ID(u8 target_id)
{
    for (u16 i = 0; i < TOTAL_IDS; i++)
    {
        if (EEPROM_Read(ID_START_ADDR + i) == target_id)
        {
            return 1;
            break;
        }
    }
    return 0;
}

void Check_Counter(void)
{
    u8 attempts = EEPROM_Read(ATTEMPTS_ADDR);

    if (attempts == 0xFF)
    {
        attempts = 0;
        EEPROM_Write(ATTEMPTS_ADDR, 0);
    }

    if (attempts >= MAX_ATTEMPTS)
    {
        UART_SendString("[LOCKED] Max attempts reached! Waiting 30s...\r\n");

        for (u8 i = 0; i < 30; i++)
        {
            _delay_ms(1000);
        }

        attempts = 0;
        EEPROM_Write(ATTEMPTS_ADDR, 0);
        UART_SendString("System Ready Again.\r\n");
    }
    else
    {
        attempts++;
        EEPROM_Write(ATTEMPTS_ADDR, attempts);

        UART_SendString("Failed Attempt: ");
        UART_SendChar(attempts + '0');
        UART_SendString("\r\n");
    }
}

void Reset_Counter(void)
{
    EEPROM_Write(ATTEMPTS_ADDR, 0);
}

void Verify_User_Card(u8 entered_id)
{
    if (Search_ID(entered_id) == 1)
    {
        SET_BIT(PORTB, LED_GREEN);
        CLR_BIT(PORTB, LED_RED);
        
        Reset_Counter();
        UART_SendString("[MATCH] Access Granted! Green LED ON.\r\n");
    }
    else
    {
        CLR_BIT(PORTB, LED_GREEN);
        SET_BIT(PORTB, LED_RED);
        
        UART_SendString("[NO MATCH] Access Denied! Red LED ON.\r\n");
        Check_Counter();
    }
}


int main(void)
{
    SET_BIT(DDRB, LED_GREEN);
    SET_BIT(DDRB, LED_RED);

    CLR_BIT(PORTB, LED_GREEN);
    CLR_BIT(PORTB, LED_RED);

    UART_Init(9600);
    TWI_Master_Init();

    UART_SendString("=== Access Control Ready ===\r\n");

    System_Init_IDs();

    _delay_ms(200);
   Verify_User_Card(0x22);

    while (1)
    {
   /* Verify_User_Card(0x99);

    _delay_ms(200);
    Verify_User_Card(0x88);

    _delay_ms(200);
    Verify_User_Card(0x77);

    _delay_ms(200);
    Verify_User_Card(0x66);

    _delay_ms(200);*/

    }

    return 0;
}
