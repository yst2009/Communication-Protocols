#include "STD_TYPES.h"
#include "BIT_MATH.h"
#include "twi.h"



void    TWI_Master_Init()
{
	
	
	TWBR = (((F_CPU / scl_freq)-16)/(2*1));
	CLR_BIT(TWSR ,TWPS0 );
	CLR_BIT(TWSR ,TWPS1 );
	
	SET_BIT(TWCR,TWEN);
	
}

void    TWI_Slave_Init_W(u8 my_address)
{
	TWAR = (u8)(my_address << 1 );
	TWCR = (1 << TWEN) | (1<<TWEA);	
    while (GET_BIT(TWCR ,TWINT )== 0);

}

void    TWI_Execute(u8 extra_flag)
{
	TWCR = (1 << TWINT) | (1 << TWEN) | extra_flag;
	while (GET_BIT(TWCR ,TWINT )== 0);
}

void    TWI_Start(void)
{
	TWI_Execute(1 << TWSTA);
}

void    TWI_RepeatedStart(void)
{
	TWI_Execute(1 << TWSTA);
}

void    TWI_Stop(void)
{
	TWCR = (1 << TWINT) | (1 << TWEN) | (1 << TWSTO);
	
	while(GET_BIT(TWCR,TWSTO) == 1);
}

void    TWI_Write(u8 data)
{
	TWDR = data ;
	
	TWI_Execute(1 << TWEA);
	
}

u8 TWI_Read_With_ACK(void)
{
	TWI_Execute(1 << TWEA);
	return TWDR;
}

u8 TWI_Read_With_NACK(void)
	{
		TWI_Execute(0U);
		return TWDR;
	}

u8 TWI_Get_Status(void)
{
	return (u8)(TWSR & 0xF8);
}


u8 i2c_write_byte(u8 data)
{
    TWI_Write(data);

    u8 status = TWI_Get_Status();

    if (status == TWI_MT_SLA_ACK || status == TWI_MT_DATA_ACK || status == 0x40)
    {
        return I2C_ACK; 
    }
    else
    {
        return I2C_NACK;
    }
}

u8 i2c_read_byte(u8 ack)
{
    u8 received_data;

    if (ack == 1)
    {
        received_data = TWI_Read_With_ACK();
    }
    else
    {
        received_data = TWI_Read_With_NACK();
    }

    return received_data;
}

u8 i2c_probe(u8 address)
{
    u8 ack_result;

    TWI_Start();
    ack_result = i2c_write_byte(address);
    TWI_Stop();

    if (ack_result == I2C_ACK)
    {
        return 1; 
    }
    else
    {
        return 0;
    }
}
